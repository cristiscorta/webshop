package roAuto;

import java.util.List;

public interface ProductDAO {

    List<Product> findAll();
    List<Product> findAllByCatId(Integer catId);
    Product findById(Integer productId);
}

package roAuto;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SecuritySession {

    boolean isSigned;
    Integer userId;

    public void markUserSigned() {

        isSigned = true;
    }

    public boolean isUserSinged() {

        return isSigned;
    }

    public boolean userNotSigned() {

        return isSigned = false;
    }

    public Integer getUserId() {

        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}


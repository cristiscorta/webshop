package roAuto;

import java.math.BigDecimal;

public class Order {

    int id;
    int iduser;
    BigDecimal price;
    int quantity;
    int idproduct;
}

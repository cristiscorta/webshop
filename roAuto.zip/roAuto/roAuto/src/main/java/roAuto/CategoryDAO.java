package roAuto;

import java.util.List;

public interface CategoryDAO {

    public List<Category> findAll();
}

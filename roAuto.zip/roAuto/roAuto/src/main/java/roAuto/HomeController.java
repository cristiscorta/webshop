package roAuto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class HomeController {

    @Autowired
    SecuritySession securitySession;

    @Autowired
    UserRegister userRegister;

    @Autowired
    DatabaseProductDAO databaseProductDAO;

    @Autowired
    DatabaseCategoryDAO databaseCategoryDAO;


    @Autowired
    private CartSession cartSession;

    @GetMapping("/index")
    public ModelAndView index(){
        ModelAndView modelAndView = new ModelAndView("index");
        return modelAndView;
    }

    @GetMapping("/singin")
    public ModelAndView singin() {
        ModelAndView modelAndView = new ModelAndView("singin");
        return modelAndView;
    }

    @GetMapping("/singout")
    public ModelAndView singout() {
        securitySession.userNotSigned();
        ModelAndView modelAndView = new ModelAndView("index");
        return modelAndView;
    }

    @GetMapping("/singup")
    public ModelAndView singup() {
        ModelAndView modelAndView = new ModelAndView("singup");
        return modelAndView;
    }

    @GetMapping("/categories")
    public ModelAndView categories() {
        if (!securitySession.isUserSinged()) {
            return new ModelAndView("redirect:/singin");
        }
        ModelAndView modelAndView = new ModelAndView("categories");
        modelAndView.addObject("singed", securitySession.isUserSinged());
        List<Category> categoriesList = databaseCategoryDAO.findAll();
        modelAndView.addObject("categories", categoriesList);
        modelAndView.addObject("nr_product",cartSession.getProductIds().size() );
        return modelAndView;
    }

    @GetMapping("/products")
    public ModelAndView showAll(@RequestParam("category_id")Integer catId) {
        if (!securitySession.isUserSinged()) {
            return new ModelAndView("redirect:/singin");

        }
        ModelAndView modelAndView = new ModelAndView("products");
        modelAndView.addObject("singed", securitySession.isUserSinged());
        List<Product> productList = databaseProductDAO.findAllByCatId(catId);
        modelAndView.addObject("products", productList);
        modelAndView.addObject("nr_product",cartSession.getProductIds().size() );
        modelAndView.addObject("logged",securitySession.isUserSinged());
        return modelAndView;
    }



    @GetMapping("/singup-action")
    public String create(
            @RequestParam("name") String name,
            @RequestParam("username") String username,
            @RequestParam("email") String email,
            @RequestParam("password") String password,
            @RequestParam("address") String address

    ) {
        User user = new User();
        user.setName(name);
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setAddress(address);

        userRegister.saveUser(user);

        return "redirect:/singin";
    }
}
